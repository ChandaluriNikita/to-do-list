import tkinter as tk
from tkinter import messagebox

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List App")

        self.tasks = []

        self.task_entry = tk.Entry(self.root, width=40, font=("Arial", 14))
        self.task_entry.pack(pady=10)

        self.add_button = tk.Button(self.root, text="Add Task", font=("Arial", 12), command=self.add_task)
        self.add_button.pack(pady=5)

        self.task_listbox = tk.Listbox(self.root, width=50, height=10, font=("Arial", 12))
        self.task_listbox.pack(pady=10)

        self.mark_done_button = tk.Button(self.root, text="Mark as Done", font=("Arial", 12), command=self.mark_done)
        self.mark_done_button.pack(pady=5)

        self.delete_button = tk.Button(self.root, text="Delete Task", font=("Arial", 12), command=self.delete_task)
        self.delete_button.pack(pady=5)

    def add_task(self):
        task = self.task_entry.get().strip()
        if task:
            self.tasks.append(task)
            self.update_listbox()
            self.task_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Input Error", "Please enter a task.")

    def delete_task(self):
        selected = self.task_listbox.curselection()
        if selected:
            del self.tasks[selected[0]]
            self.update_listbox()
        else:
            messagebox.showwarning("Selection Error", "Please select a task to delete.")

    def mark_done(self):
        selected = self.task_listbox.curselection()
        if selected:
            task = self.tasks[selected[0]]
            if not task.endswith("✓"):
                self.tasks[selected[0]] = task + " ✓"
                self.update_listbox()
        else:
            messagebox.showwarning("Selection Error", "Please select a task to mark as done.")

    def update_listbox(self):
        self.task_listbox.delete(0, tk.END)
        for task in self.tasks:
            self.task_listbox.insert(tk.END, task)

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
